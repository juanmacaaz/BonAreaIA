package com.example.clientnotificator;

public enum TipoIncidencia {
    VERDE, AMARILLO, ROJO
}
